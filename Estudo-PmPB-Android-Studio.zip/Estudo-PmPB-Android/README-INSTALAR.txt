ESTUDO PMPB 3.0 — ANDROID

Este pacote é um PROJETO ANDROID STUDIO, ainda NÃO é um APK compilado.

COMPILAR O APK NO COMPUTADOR
1. Instale Android Studio no Windows, macOS ou Linux.
2. Extraia este ZIP e abra a pasta Estudo-PmPB-Android no Android Studio.
3. Aguarde o Gradle sincronizar e baixar os componentes Android necessários.
   Se for solicitado instalar Gradle, use o Gradle disponível no Android Studio;
   o ZIP não inclui gradle-wrapper.jar.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. No resultado, escolha Locate. APK de teste: app/build/outputs/apk/debug/app-debug.apk.
6. Envie o APK para o Android e abra o arquivo. Autorize a instalação
   de aplicativos desta fonte quando o Android solicitar.

OBSERVAÇÕES
- Material didático funciona sem internet: HTML/CSS/JS e questões estão embutidos.
- Dados são armazenados localmente no WebView deste aplicativo, separados do navegador.
- Importação de arquivos, backup por download e recursos de fala podem precisar
  de integração nativa adicional, e não foram validados num Android real.
- Não é aplicativo oficial da PMPB; usa como referência edital anterior.
- O ícone foi preparado a partir da imagem fornecida pelo usuário.

OPÇÃO SEM ANDROID STUDIO — GITHUB ACTIONS
1. Crie um repositório no GitHub e envie os arquivos DE DENTRO da pasta Estudo-PmPB-Android,
   mantendo as pastas app e .github na raiz do repositório.
2. Na aba Actions, abra 'Gerar APK Android' e clique em Run workflow.
3. Ao finalizar, abra a execução e baixe o artefato 'Estudo-PmPB-APK'.
4. Extraia o ZIP baixado pelo GitHub para obter app-debug.apk.
5. Instale o APK no celular.
Não publique dados pessoais no repositório. Este projeto contém somente código e questões.
